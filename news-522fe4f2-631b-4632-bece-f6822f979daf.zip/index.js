/* eslint-disable  func-names */
/* eslint quote-props: ["error", "consistent"]*/
/**
 * This sample demonstrates a simple skill built with the Amazon Alexa Skills
 * nodejs skill development kit.
 * This sample supports multiple lauguages. (en-US, en-GB, de-DE).
 * The Intent Schema, Custom Slots and Sample Utterances for this skill, as well
 * as testing instructions are located at https://github.com/alexa/skill-sample-nodejs-fact
 **/

'use strict';
const Alexa = require('alexa-sdk');

//=========================================================================================================================================
//TODO: The items below this comment need your attention.
//=========================================================================================================================================

//Replace with your app ID (OPTIONAL).  You can find this value at the top of your skill's page on http://developer.amazon.com.
//Make sure to enclose your value in quotes, like this: const APP_ID = 'amzn1.ask.skill.bb4045e6-b3e8-4133-b650-72923c5980f1';
const APP_ID = 'amzn1.ask.skill.ae50a379-34cd-4441-b774-f92041d4cee5';

const SKILL_NAME = 'My News';
const GET_FACT_MESSAGE = "Todays news is :";
const HELP_MESSAGE = 'You can say tell me a news or, you can say exit... What can I help you with?';
const HELP_REPROMPT = 'What can I help you with?';
const STOP_MESSAGE = 'Goodbye!';

//=========================================================================================================================================
//TODO: Replace this data with your own.  You can find translations of this data at http://github.com/alexa/skill-sample-node-js-fact/data
//=========================================================================================================================================
const data = [
  'School Assembly: Ground breaks on new T.W. Ogg Elementary School.',
'Clute will seek economic development funding for park electrical upgrades.',
'Bucs pull out hardball thriller.',
'Bulldogs once again score big at meet.',
'Purnell Relays to get good weather.',
'Lady Eagles take down Pasadena First Baptist.',
'Wildcats race to strong finish at Purnell Relays.',
'Local Super Heavy Weights ready to lay it on the line.',
'Local Super Heavy Weights ready to lay it on the line.',
'Visually impaired man clears Odisha Public Service Commission examination.',
'Sanjeev Balyan to India Today: Want small riot cases withdrawn to save youth from never ending trials.',
'Kashmiri separatist Asiya Andrabi seen singing Pakistani national anthem.',
'Yogi Adityanath congratulates candidates after BJPs victory in Rajya Sabha polls.',
'JNU protest: Women Delhi Police officers manhandle female journalist.',
'Lalu Prasad Yadav sentenced to 7 years in jail in fourth fodder scam case.',
'Kamal Haasan says he’s not anti-BJP but anti-everything mediocre',
'SEE: The view from inside Virat Kohli and Anushka Sharmas house will leave you stunned,',
'Google Pixel 3 will likely have a notch and you can blame Android P for it',
'Asiya Andrabis hate rant in Kashmir; Exclusive with Gen VK Singh; more.',
'Yogi Adityanath :Yogi Adityanath congratulates candidates after BJPs victory in Rajya Sabha polls.',
'Young Kashmiri girl blinded by pellets gets admission in top school.',
'Rahul Gandhi visits Sringeri temple during his two day Karnataka visit',
'I was 100 per cent sure I will be cleared by BCCIs anti-corruption unit: Mohammed Shami',

];

//=========================================================================================================================================
//Editing anything below this line might break your skill.
//=========================================================================================================================================

const handlers = {
    'LaunchRequest': function () {
        this.emit('GetNewFactIntent');
    },
    'GetNewFactIntent': function () {
        const factArr = data;
        const factIndex = Math.floor(Math.random() * factArr.length);
        const randomFact = factArr[factIndex];
        const speechOutput = GET_FACT_MESSAGE + randomFact;

        this.response.cardRenderer(SKILL_NAME, randomFact);
        this.response.speak(speechOutput);
        this.emit(':responseReady');
    },
    'AMAZON.HelpIntent': function () {
        const speechOutput = HELP_MESSAGE;
        const reprompt = HELP_REPROMPT;

        this.response.speak(speechOutput).listen(reprompt);
        this.emit(':responseReady');
    },
    'AMAZON.CancelIntent': function () {
        this.response.speak(STOP_MESSAGE);
        this.emit(':responseReady');
    },
    'AMAZON.StopIntent': function () {
        this.response.speak(STOP_MESSAGE);
        this.emit(':responseReady');
    },
};

exports.handler = function (event, context, callback) {
    const alexa = Alexa.handler(event, context, callback);
    alexa.APP_ID = APP_ID;
    alexa.registerHandlers(handlers);
    alexa.execute();
};
